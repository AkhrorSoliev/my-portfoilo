export default [
  {
    title: "Example",
    github: "example.uz",
    vercel: "example.uz",
  },
];
